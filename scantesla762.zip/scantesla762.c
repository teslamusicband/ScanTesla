#define REV "ScanTesla  V-7.62  June 4, 2006  Terry Fritz "

/* This program has no copyright, GPL, copyleft, trademarks, or real owner
   of this Public Domain base version. Anyone can copy, steal, plagiarize,
   change, and use it as they wish.

   The latest version is probably at http://drsstc.com/~terrell/modeling/

   The general guide to the program is at http://www.drsstc.com/~terrell/modeling/ScanTesla.pdf

   This program iterates through and tests a large number of Tesla coil
   parameters in search of those parameters that give the best output sparks
HISTORY
	V-1.00 May 14, 2005	Terry   Original starting version
	V-2.00 June 10, 2005 Terry  Added Antonio's Calculation Engine "ACE"
	V-3.00 June 11, 2005 Terry  Cleaned up everything and did a lot of testing
	V-4.00 June 12, 2005 Terry	Added automatic dt and conventional coil hooks
	V-5.00 June 12, 2005 Terry  Added file input
	V-5.10 June 13, 2005 Terry  Changed all %e, %f, %d to %le, %lf, %ld.  Removed <conio.h>.
	V-5.20 June 13, 2005 Terry	Added revision printout, fixed peak time bug, added Cprimary RMS current.
	V-6.00 June 14, 2005 Terry  Added output file of last best waveform's state data. Fixed T1_inc"1" bug.
								Added Bang Energy Limit.
	V-6.10 June 14, 2005  Terry  Change goal time printout. Fixed Cpri RMS current.
	V-6.11 June 16, 2005  Terry  Took out t variable and fixed comment line.  Fixed T = 1uS bug in putput file.
	V-6.20 June 16, 2005  Terry  Added streamer power profile.
	V-6.21 June 17, 2005  Terry  Added load energy rise time.  Cleaned up messy code.
	V-6.22 June 18, 2005  Terry  Fixed Vin/Vin_old problem.  Few comment fixes.
	V-6.23 June 19, 2005  Terry  In DRSSTC case, Vin = -Vin after dwell time.
	V-6.24 June 19, 2005  Terry  Added antiparallel diode effects for DRSSCT after dwell time shutdown.
	V-7.00 June 20, 2005  Terry	 Added full data output file.  Added Vin to model output file.
	V-7.01 June 21, 2005  Terry  Fixed Vin in wavevorms.txt file header.
	V-7.10 June 23, 2005  Terry  Added Dwell Time loop
	V-7.20 June 23, 2005  Terry  Automatic L1 Range
	V-7.30 June 23, 2005  Terry  Added BPS style calculations Fixed fabs vs abs bug <- BIG BUG!!   Helped screen Jitter
	V-7.31 June 23, 2005  Terry  Fixed LERT file printing bug.
	V-7.32 June 25, 2005  Terry  Init Vin before vin_old = Vin. Cleaned up screen display. Added total model calculations.
								 Changed outfile name to outputdata.csv.  Fixed power bug for conventional coil.
	V-7.33 June 25, 2005  Terry  Added fail code to running screen.
	V-7.40 July 1, 2005  Terry  Started to add dynamic streamer loading.  Took out GoalTime
	V-7.50 May 31, 2006  Terry  For SISG, LSrms is important so I added it.  Fixed double outdata.csv printing.  Stopped
								Wavform file on goal type 2 - MUCH faster in mode 2.  Fixed LoopTotal.
	V-7.51 May 31, 2006  Terry  Removed automatic L1 tuning.  Fixed Automatic streamer modeling run-on problem.
								Vastly improved automatic streamer model.
	V-7.60 June 1, 2006  Terry  Vastly improved full dynamic streamer model.  Vbreakout, StrikeDistance.
	V-7.61 June 4, 2006  Terry  Used new data to refine C load.  Terminal diameter is new factor.
	V-7.62 June 4, 2006  Terry  Fixed bugs.  Added longest leader search function (goal type 3).  Reworked auto load model.
								Added conventional coil quench time.

FUTURE IMPROVMENTS
Marco suggests using random parameters or genetic programming to scan large areas.

NOTES

	Antonio supplies the magic calculating engine for solving the nodes.
	I basically just add the input and output scanning stuff.

DRSSTC simulator
By Antonio Carlos M. de Queiroz acmq@coe.ufrj.br
Version 1.0 - 6/6/2005

This program simulates the structure:
    +v1-      k12         +v3-
 +---C1--R1--+   +--R2--+--C3--+
+|         + |   | +    |  +   |
vin       i1 L1 L2 i2   C2 v2  R3
-|         - |   | -    |  -   |
 +-----------+   +------+------+
*/

#include <stdio.h>
//#include <string.h>  //  Used where ??
//#include <stdlib.h>  //  Used where ??
//#include <ctype.h>   //  Used where ??
#include <math.h>    //  Used where ??
#include <conio.h> //Used for line 929/930 to put the cursor at the top left of screen. See line 928 if not available.

/* INPUTS */
	double C1 = 0.0;  				/* Cprimary in Farads */
	double  C1_start = 0.0;
	double  C1_stop = 0.0;
	double  C1_inc = 0.0;
	double R1 = 0.0;				/* Rprimary in Ohms */
	double	R1_start = 0.0;
	double	R1_stop = 0.0;
	double	R1_inc = 0.0;
	double L1 = 0.0;				/* Lprimary in Heneries */
	double	L1_start = 0.0;
	double	L1_stop = 0.0;
	double	L1_inc = 0.0;
	double L2 = 0.0;				/* Lsecondary in Heneries */
	double	L2_start = 0.0;
	double	L2_stop = 0.0;
	double	L2_inc = 0.0;
	double K12 = 0.0;				/* primary to secondary coupling coefficient */
	double	K12_start = 0.0;
	double  K12_stop = 0.0;
	double	K12_inc = 0.0;
	double R2 = 0.0;				/* Rsecondary in Ohms */
	double 	R2_start = 0.0;
	double 	R2_stop = 0.0;
	double	R2_inc = 0.0;
	double C2 = 0.0;				/* Cterminal in Farads */
	double	C2_start = 0.0;
	double 	C2_stop = 0.0;
	double 	C2_inc = 0.0;
	double C3 = 0.0;				/* Cload in Farads */
	double	C3_start = 0.0;
	double	C3_stop = 0.0;
	double	C3_inc = 0.0;
	double R3 = 0.0;				/* Rload in Ohms */
	double	R3_start = 0.0;
	double 	R3_stop = 0.0;
	double 	R3_inc = 0.0;
	double T1 = 0.0;				/* DRSSTC T1 time in Seconds */
	double	T1_start = 0.0;
	double	T1_stop = 0.0;
	double	T1_inc = 0.0;			/* Negative value for automatic dt */
	double DwellTime = 0.0;			/* T1 on time */
	double 	DwellTime_start = 0.0;
	double	DwellTime_stop = 0.0;
	double	DwellTime_inc = 0.0;

	double Vrail = 0.0;				/* DRSSTC input voltage in Volts */
	double VCpri_init = 0.0;		/* Initital voltage in Cp for conventional coil case */
	double Current_Limit = 0.0; 	/* Primary Current Limit (set high for conventional coil) */
	double CoilPower_Limit = 0.0;
	int Goal_Type = 0;				/* 0 = maximum VCtop voltage  1 = maximum steamer power */
	int Goal_Type1 = 0;
	long int PrintNumber = 0.0;

// Internal Variables
	double Vin = 0.0;
	double VCpri_max = 0.0;
	double ILpri_max = 0.0;
	double VCsec_max = 0.0;
	double Eload = 0.0;				/* Power to R3/bang */
	double CoilPower = 0.0;  		/* Bang power (watts/bang) */
	double Cpri_RMSi = 0.0;
	double Isec_RMSi = 0.0;
	long int GoalNum = 0.0;
	long int ModelNumber = 0;
	double goal = 0.0;
	double goal_max = 0.0;
	int fail = 0;
	int ChartSave = 0;
	double pi = 3.14159265359;
	double T1_inc1 = 0.0;
	double C3_inc1 = 0.0;
	double BPS = 0.0;
	long int LoopTotal = 0;
	long int LoopTotalTemp = 0;
	char buffer[256];
	double LeaderLength = 0.0;
	double Eload0 = 0.0;			/*variables for streamer rise time*/
	double Eload1 = 0.0;
	double TEload = 0.0;
	double TEload0 = 0.0;
	double TEload1 = 0.0;
	double Vin_old = 0.0;
	int screen = 0;
	double TerminalDiameter = 0.0;
	double StrikeDistance = 0.0;
	double LengthTemp = 0.0;
	double TimeTemp = 0.0;
	double C3_1 = 0.0;
	int Strike = 0;

#define filename1 "output.txt"
#define filename2 "input.txt"
#define filename3 "waveforms.csv"
#define filename4 "ouputdata.csv"
typedef double matrix [6][6];
typedef double vector [6];
int i,j,k;
double G11,G12,G21,G22,M,d;
matrix A,MT;
vector B,X0,X1,Xn;
FILE* output;
FILE* input;
FILE* option;
FILE* data;

/*SUBRoutine that inverts a matrix in place */
void Invert(int n, matrix M)
{
  int i,k,j;
  double d,e;

  for (k=1; k<=n; k++) {
    d=M[k][k]; // May need pivotal condensation, omitted
    if (fabs(d)<1e-12) {
      printf("Something wrong (line %d). Inversion impossible\n",k);
      exit(0);
    }
    M[k][k]=1/d;
    for (j=1; j<=n; j++)
      if (j!=k) M[k][j]=-M[k][j]/d;
    for (i=1; i<=n; i++) {
      if (i!=k) {
        e=M[i][k];
        M[i][k]=M[i][k]/d;
        for (j=1; j<=n; j++)
          if (j!=k) M[i][j]=M[i][j]+M[k][j]*e;
      }
    }
  }
}




int main(void)
{

/* File input of above parameters */
input=fopen(filename2,"r");

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C1_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C1_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C1_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R1_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R1_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R1_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&L1_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&L1_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&L1_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&L2_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&L2_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&L2_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&K12_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&K12_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&K12_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R2_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R2_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R2_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C2_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C2_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C2_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C3_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C3_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&C3_inc1);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&TerminalDiameter);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&StrikeDistance);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R3_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R3_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&R3_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&T1_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&T1_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&T1_inc1);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&Vrail);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&VCpri_init);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&BPS);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&DwellTime_start);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&DwellTime_stop);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&DwellTime_inc);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&Current_Limit);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%le",&CoilPower_Limit);
        	break;
        	}
	}

while (1)
	{
	buffer[0]= (char)0;
	fgets(buffer,256,input);
	if ( buffer[0] != '*')
        	{
        	sscanf(buffer,"%i",&Goal_Type1);
        	break;
        	}
	}
	Goal_Type = abs(Goal_Type1);

fclose(input);

// Print out the input variables to screen and a file.
printf(REV "\n");
printf("C1 %le %le %le \n", C1_start, C1_stop, C1_inc);
printf("R1 %le %le %le \n", R1_start, R1_stop, R1_inc);
printf("L1 %le %le %le \n", L1_start, L1_stop, L1_inc);
printf("L2 %le %le %le \n", L2_start, L2_stop, L2_inc);
printf("K12 %le %le %le \n", K12_start, K12_stop, K12_inc);
printf("R2 %le %le %le \n", R2_start, R2_stop, R2_inc);
printf("C2 %le %le %le \n", C2_start, C2_stop, C2_inc);
printf("C3 %le %le %le \n", C3_start, C3_stop, C3_inc1);
printf("R3 %le %le %le \n", R3_start, R3_stop, R3_inc);
printf("T1 %le %le %le \n", T1_start, T1_stop, T1_inc1);
printf("Terminal Diameter %le \n", TerminalDiameter);
printf("Strike Distance %le \n", StrikeDistance);
printf("Vrail %le \n", Vrail);
printf("VCpri_init %le \n", VCpri_init);
printf("BPS %le \n", BPS);
printf("DwellTime %le %le %le \n", DwellTime_start, DwellTime_stop, DwellTime_inc);
printf("Current_Limit %le \n", Current_Limit);
printf("CoilPower_Limit %le \n", CoilPower_Limit);
printf("Goal Type %i \n", Goal_Type);

output=fopen(filename1,"w");
fprintf(output, REV "\n");
fprintf(output,"C1 %le %le %le \n", C1_start, C1_stop, C1_inc);
fprintf(output,"R1 %le %le %le \n", R1_start, R1_stop, R1_inc);
fprintf(output,"L1 %le %le %le \n", L1_start, L1_stop, L1_inc);
fprintf(output,"L2 %le %le %le \n", L2_start, L2_stop, L2_inc);
fprintf(output,"K12 %le %le %le \n", K12_start, K12_stop, K12_inc);
fprintf(output,"R2 %le %le %le \n", R2_start, R2_stop, R2_inc);
fprintf(output,"C2 %le %le %le \n", C2_start, C2_stop, C2_inc);
fprintf(output,"C3 %le %le %le \n", C3_start, C3_stop, C3_inc1);
fprintf(output,"R3 %le %le %le \n", R3_start, R3_stop, R3_inc);
fprintf(output,"T1 %le %le %le \n", T1_start, T1_stop, T1_inc1);
fprintf(output,"Terminal Diameter %le \n", TerminalDiameter);
fprintf(output,"Strike Distance %le \n", StrikeDistance);
fprintf(output,"Vrail %le \n", Vrail);
fprintf(output,"VCpri_init %le \n", VCpri_init);
fprintf(output,"BPS %le \n", BPS);
fprintf(output,"DwellTime %le %le %le \n", DwellTime_start, DwellTime_stop, DwellTime_inc);
fprintf(output,"Current_Limit %le \n", Current_Limit);
fprintf(output,"CoilPower_Limit %le \n", CoilPower_Limit);
fprintf(output,"Goal Type %i \n", Goal_Type);
fclose(output);

data=fopen(filename4,"w");
fprintf(data,"Model Number,C1,R1,L1,L2,K12,R2,C2,C3,R3,BPS,Dwell (T1) Time,abs(ILp_max),ICp_rms,abs(VCp_max),ILs_rms,abs(VCs_max),Coil Power,Load Power,Fo_pri,Fo_sec,LERT,Leader Length\n");
fclose(data);

LoopTotal = 1;
LoopTotalTemp = (abs((C1_stop * 1.00000001 - C1_start) / C1_inc)); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
LoopTotalTemp = (abs((R1_stop * 1.00000001 - R1_start) / R1_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
LoopTotalTemp = (abs((L2_stop * 1.00000001 - L2_start) / L2_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
LoopTotalTemp = (abs((K12_stop * 1.00000001 - K12_start) / K12_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
LoopTotalTemp = (abs((R2_stop * 1.00000001 - R2_start) / R2_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
LoopTotalTemp = (abs((C2_stop * 1.00000001 - C2_start) / C2_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
if (C3_inc1 > 0.0) {LoopTotalTemp = (abs((C3_stop * 1.00000001 - C3_start) / C3_inc1) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}}
if (C3_inc1 > 0.0) {C3_inc = C3_inc1;} else {C3_inc = 999999;}
LoopTotalTemp = (abs((R3_stop * 1.00000001 - R3_start) / R3_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
LoopTotalTemp = (abs((DwellTime_stop * 1.00000001 - DwellTime_start) / DwellTime_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}
LoopTotalTemp = (abs((L1_stop * 1.00000001 - L1_start) / L1_inc) + 1); if (LoopTotalTemp > 0) {LoopTotal = LoopTotal * LoopTotalTemp;}


// Main iteration loops that scan the parameters

for (C1 = C1_start; C1 <= C1_stop * 1.00000001; C1 = C1 + C1_inc)
		{
for (R1 = R1_start; R1 <= R1_stop * 1.00000001; R1 = R1 + R1_inc)
		{
for (L2 = L2_start; L2 <= L2_stop * 1.00000001; L2 = L2 + L2_inc)
		{
for (K12 = K12_start; K12 <= K12_stop * 1.00000001; K12 = K12 + K12_inc)
		{
for (R2 = R2_start; R2 <= R2_stop * 1.00000001; R2 = R2 + R2_inc)
		{
for (C2 = C2_start; C2 <= C2_stop * 1.00000001; C2 = C2 + C2_inc)
		{
for (C3_1 = C3_start; C3_1 <= C3_stop * 1.00000001; C3_1 = C3_1 + fabs(C3_inc))
		{
for (R3 = R3_start; R3 <= R3_stop * 1.00000001; R3 = R3 + R3_inc)
		{
for (L1 = L1_start; L1 <= L1_stop * 1.00000001; L1 = L1 + L1_inc)
		{
for (DwellTime = DwellTime_start; DwellTime <= DwellTime_stop * 1.00000001; DwellTime = DwellTime + DwellTime_inc)
		{

if (T1_inc1 < 0.0) {T1_inc = 2*pi*sqrt(L1*C1)/100.0;} else {T1_inc = T1_inc1;}  /*default T1_inc value (100 step/cycle)*/

ModelNumber = ModelNumber + 1;

MainCalc:// Main calculation engine that finds the output paramters.

//ChartSave = 0  is the first pass
//ChartSave = 1  is a flag to repeat the same pass again put store everything to files
//ChartSave = 2  is the actual second pass

if (ChartSave == 1) ChartSave = 2; else ChartSave = 0;

// Reset for the run
printf("%li/%li ", ModelNumber, LoopTotal);
if (fail == 0) printf("Goal   \r");
if (fail == 1) printf("Current\r");
if (fail == 2) printf("Power  \r");

// Reset varibles/run
	Eload0 = Eload * 0.1;  //Set variables for Load Energy Rise Time
	Eload1 = Eload * 0.9;	// 10% to 90% rise time values
	TEload = 0.0;
	TEload0 = 0.0;
	TEload1 = 0.0;
  	goal = 0.0;
  	fail = 0;
	LengthTemp = 0.0;
	VCpri_max=0.0;
  	ILpri_max=0.0;
  	VCsec_max = 0.0;
  	Cpri_RMSi = 0.0;
	Isec_RMSi = 0.0;
	CoilPower = 0.0;
	Strike = 0;
  	Eload = 0.0;
	Vin_old = 0.0;
	Vin = 0.0;
  	for (j=1; j<6; j++) {X0[j]=0.0; X1[j]=0.0; Xn[j]=0.0;}

  	X0[1] = VCpri_init;  //this sets initial conditions on Cprimary

if (ChartSave == 2 && Goal_Type != 2)
	{
      option=fopen(filename3,"w");
      fprintf(output,"Time , Vin , VCpri , VCsec , VCload , ILpri , ILsec, Eload (J/bang) , Cload \n");
      fclose(option);
      option=fopen(filename3,"a");
	}

// Actual model run over time T1_start to T1_stop.

	for (T1 = T1_start; T1 <= T1_stop * 1.00000001; T1 = T1 + T1_inc)
{

//Determin the model with matrix calculations


// Dynamic streamer model********************************************************

	LeaderLength = 27.19734 * sqrt(0.5 * VCsec_max * VCsec_max * (C2 + C3));  //Secondary energy length.

	if (LeaderLength > StrikeDistance) LeaderLength = StrikeDistance;

	if (T1 != T1_start && C3_inc1 < 0.0)  //Do this if active streamer modeling is enabled and the model has run once.
		{

		C3 = (LeaderLength - TerminalDiameter) / 6 * 1.0e-12;  //Streamer capacitive load.

		if (C3 < 0.0) C3 = 0.0;


	//Streamer strike to ground
		if (LeaderLength >= StrikeDistance && Strike == 0) //Turn Strike on.
			{
			Strike = 1;
			TimeTemp = T1;
			}

		if (T1 >= TimeTemp + 2 * (2 * pi * sqrt(L1 * C1))  && Strike == 1) //Turn Strike off.
		    {
			Strike = 2;
		   	}

		if (Strike == 1) //Strike topload drain to Eload.
			{
			Eload += 0.5 * C2 * X0[2] * X0[2] * T1_inc + 0.5 * C3 * X0[3] * X0[3] * T1_inc;
			X0[2] = 0.0;
			X0[3] = 0.0;
			}

	} else {C3 = C3_1;}

// Dynamic streamer model********************************************************


if ((T1 == T1_start) || (C3_inc < 0.0)) //Don't keep repeating the matrix solution unless C1 changes.
	{

		/* Inverts [L] matrix */
		  M=K12*sqrt(L1*L2);
		  d=L1*L2-M*M;
		  G11=L2/d;
 		  G22=L1/d;
 		  G12=-M/d;
		  G21=G12;
		  /* Assembles the state equations dx/dt=[A]*x+B*vin */
		  A[1][1]=0; 	A[1][2]=0; 			A[1][3]=0; 			A[1][4]=1/C1; 		A[1][5]=0;
		  A[2][1]=0; 	A[2][2]=-1/(R3*C2); A[2][3]=1/(R3*C2); 	A[2][4]=0; 			A[2][5]=-1/C2;
		  A[3][1]=0; 	A[3][2]=1/(R3*C3); 	A[3][3]=-1/(R3*C3); A[3][4]=0; 			A[3][5]=0;
 		  A[4][1]=-G11; A[4][2]=G12; 		A[4][3]=0; 			A[4][4]=-G11*R1; 	A[4][5]=-G12*R2;
		  A[5][1]=-G12; A[5][2]=G22; 		A[5][3]=0; 			A[5][4]=-G12*R1; 	A[5][5]=-G22*R2;
		  B[1]=0; 		B[2]=0; 			B[3]=0; 			B[4]=G11; 			B[5]=G21;

		   /* Generates MT=([I]-(dt/2)*[A])^(-1) */
		  for (i=1; i<6; i++)
 		   for (j=1; j<6; j++)
		      if (i==j) MT[i][j]=1-(T1_inc/2)*A[i][j];
		      else MT[i][j]=-(T1_inc/2)*A[i][j];
		  Invert(5,MT);
		  /* Sets the initial state */
 }

  Vin_old = Vin;
  if (X0[4] >= 0) Vin=Vrail; else Vin=-Vrail;	//Inputs Vin for DRSSTC case
  if (T1 > DwellTime) Vin = -Vin;					//Dwell time shutdown
  if ((T1 > DwellTime) && ((Vin > 0) && (X0[4] > 0))) X0[4] = 0.0;	//Antiparallel diodes in DRSSTC
  if ((T1 > DwellTime) && ((Vin < 0) && (X0[4] < 0))) X0[4] = 0.0;	//Antiparallel diodes in DRSSTC

  if (VCpri_init != 0.0 && T1 >= DwellTime) Vin = X0[1];  //Quench time for conventional coils.

      /* X1=X0+(dt/2)*[A]*X0+(dt/2)*B*(vin(t0)+vin(t0+dt)) */
      for (j=1; j<6; j++) {
        X1[j]=X0[j];
        for (k=1; k<6; k++) X1[j]+=(T1_inc/2)*(A[j][k]*X0[k]);
        X1[j]+=(T1_inc/2)*B[j]*(Vin_old+Vin);
      }
      /* Xn=[MT]*X1 */
      for (j=1; j<6; j++) {
        Xn[j]=0;
        for (k=1; k<6; k++) Xn[j]+=MT[j][k]*X1[k];
      }
      for (j=1; j<6; j++) X0[j]=Xn[j];

/* Output paramters are now calculated and availiable per this time step

X0[1] = VC1
X0[2] = VC2
X0[3] = VC3
X0[4] = IL1
X0[5] = IL2

*/

	  	if (fabs(X0[4]) > Current_Limit) fail = 1; /*Fail the model if the primary current trips */

	  	if (VCpri_init == 0.0) {CoilPower += Vin*X0[4]*T1_inc;} else {CoilPower = CoilPower = 0.5 * C1 * VCpri_init * VCpri_init * BPS;}

	  	Eload += (X0[2]-X0[3])*(X0[2]-X0[3])/R3*T1_inc;    /*Load energy/bang */
		Cpri_RMSi += X0[4] * X0[4] * T1_inc;
		Isec_RMSi += X0[5] * X0[5] * T1_inc;

	  	if (fabs(X0[4]) > fabs(ILpri_max)) ILpri_max = X0[4];		/*max value traps */
      	if (fabs(X0[1]) > fabs(VCpri_max)) VCpri_max = X0[1];
	  	if (fabs(X0[2]) > fabs(VCsec_max)) VCsec_max = X0[2];

		if (Goal_Type == 0) {if (fabs(X0[2]) > fabs(goal)) {goal = X0[2];}}	/*Goal Seek function (Vsec_max)*/

		if ((Eload > Eload0) && (TEload0 == 0.0)) TEload0 = T1; //Rise time limits
		if ((Eload > Eload1) && (TEload1 == 0.0)) {TEload1 = T1; TEload = TEload1 - TEload0;}

//print waveform.csv file
if (ChartSave == 2 && Goal_Type != 2) {if (Goal_Type1 > -1) {fprintf(option,"%le , %le , %le , %le , %le , %le , %le , %le, %le \n", T1,Vin,X0[1],X0[2],X0[3],X0[4],X0[5],Eload,C3);}}

}  //T1 loop end

if (ChartSave == 2 && Goal_Type != 2) fclose(option);

	Cpri_RMSi = sqrt(Cpri_RMSi)*sqrt(BPS);  // Finish RMS current calculation
	Isec_RMSi = sqrt(Isec_RMSi)*sqrt(BPS);
	if (VCpri_init == 0.0) CoilPower = CoilPower * BPS;
	if (Goal_Type == 1) {if (fabs(Eload) > fabs(goal)) {goal = fabs(Eload);}}	/*Goal Seek function (Eload)*/

	if (Goal_Type == 3) {if (fabs(LeaderLength) > fabs(goal)) {goal = fabs(LeaderLength);}}	/*Goal Seek function (Eload)*/

	if (CoilPower > CoilPower_Limit) fail = 2;  /*fail the model if the bang energy is too high */

//  Check if we have a new winning goal, report it if yes.
//if ((((fabs(goal) > fabs(goal_max)) && (fail == 0)) || (Goal_Type == 2)) && (ChartSave == 0)) {ChartSave = 1;}

if (ChartSave == 0) ChartSave = 1;
if (fabs(goal_max) > fabs(goal) && Goal_Type != 2) ChartSave = 0;
if (fail != 0 && Goal_Type != 2) ChartSave = 0;


			if (Goal_Type != 2 && ChartSave == 2)  //print to screen and file if new goal
			{

			// Screen output

			goal_max = goal;
			GoalNum = GoalNum + 1;
			//printf("\n\n");  // <- Use if conio.h is not avaialable instead of next two lines.
			if (screen == 0) {screen = 1; clrscr();} // Clear screen on first display
			gotoxy(1,1); //puts cursor at top left of screen
			printf(REV "\n");
			printf("Goal = %18.9lf  ", goal_max);
			if (Goal_Type == 0) printf("Maxium Secondary Voltage \n");
			if (Goal_Type == 1) printf("Maxium Load Energy \n");
			if (Goal_Type == 2) printf("Print all models \n");
			if (Goal_Type == 3) printf("Maximum Leader Length \n");
			printf("Model Number = %ld \n", ModelNumber);
			printf("Goal Number = %ld \n", GoalNum);
			printf("Cprimary (nF) = %8.3lf \n", C1/1.0e-9);
			printf("Lprimary (uH) = %8.3lf \n", L1/1.0e-6);
			printf("Rprimary (Ohm) = %6.3lf \n", R1);
			printf("Coupling = %4.4lf \n" , K12);
			printf("Csecondary (pF) = %5.2lf \n", C2/1.0e-12);
			printf("Lsecondary (mH) = %8.3lf \n", L2/1.0e-3);
			printf("Rsecondary (Ohm) = %6.1lf \n", R2);
			printf("Cload (pF) = %5.3lf \n" , C3/1.0e-12);
			printf("Rload (kOhm) = %6.1lf \n", R3/1000.0);
			printf("BPS = %8.3lf \n", BPS);
			printf("Dwell (T1) Time (uSec) = %6.1lf \n", DwellTime*1e6);
			printf("Ilprimay Maximum (A) = %7.2lf \n", ILpri_max);
			printf("ICprimary RMS (Arms) = %5.2lf   ILsecondary RMS (Arms) = %2.5lf \n", Cpri_RMSi, Isec_RMSi);
			printf("VCprimary Maximum (kV) = %7.3lf \n", VCpri_max/1000.0);
			printf("VCsecondary Maximum (kV) = %9.3lf \n", VCsec_max/1000.0);
			printf("Coil Power (W) = %9.2lf   Primary Bang Energy (J) = %7.3lf \n", CoilPower, CoilPower / BPS);
			printf("Load Power (W) = %9.2lf   Load Bang Energy (J) = %7.3lf \n", Eload*BPS, Eload);
			printf("Leader Length (in) = %6.2f  ",LeaderLength);
			if (Strike == 0) printf("Streamer \n"); else printf("Strike   \n");
			printf("Primary F0 (Hz) = %8.1lf   Secondary F0 (Hz) = %8.1lf\n",1/(2 * pi * sqrt(L1 * C1)), 1/(2 * pi * sqrt(L2 * C2)));
			printf("Load Energy Rise Time (uSec) = %6.1lf \n", TEload*1e6);

			//File output
			output=fopen(filename1,"a");
			fprintf(output,"\n\n\n");
			fprintf(output, REV "\n");
			fprintf(output,"Goal = %le  ", goal_max);
			if (Goal_Type == 0) fprintf(output,"Maxium Secondary Voltage \n");
			if (Goal_Type == 1) fprintf(output,"Maxium Load Energy \n");
			if (Goal_Type == 2) fprintf(output,"Print all models \n");
			if (Goal_Type == 3) fprintf(output,"Maximum Leader Length \n");
			fprintf(output,"Model Number = %ld \n", ModelNumber);
			fprintf(output,"Goal Number = %ld \n", GoalNum);
			fprintf(output,"Cprimary = %le \n", C1);
			fprintf(output,"Lprimary = %le \n", L1);
			fprintf(output,"Rprimary = %le \n", R1);
			fprintf(output,"Coupling = %lf \n" , K12);
			fprintf(output,"Csecondary = %le \n", C2);
			fprintf(output,"Lsecondary = %le \n", L2);
			fprintf(output,"Rsecondary = %le \n", R2);
			fprintf(output,"Cload = %le \n" , C3);
			fprintf(output,"Rload = %le \n", R3);
			fprintf(output,"BPS = %lf \n", BPS);
			fprintf(output,"Dwell (T1) Time = %le \n", DwellTime);
			fprintf(output,"Ilprimay Maximum = %lf \n", ILpri_max);
			fprintf(output,"ICprimary RMS (Arms) = %lf   ILsecondary RMS (Arms) = %lf \n", Cpri_RMSi, Isec_RMSi);
			fprintf(output,"VCprimary Maximum = %lf \n", VCpri_max);
			fprintf(output,"VCsecondary Maximum = %lf \n", VCsec_max);
			fprintf(output,"Coil Power = %lf   Primary Bang Energy = %lf \n", CoilPower, CoilPower / BPS);
			fprintf(output,"Load Power = %lf   Load Bang Energy = %lf \n", Eload*BPS, Eload);
			fprintf(output,"Leader Length (in) = %lf  ",LeaderLength);
			if (Strike == 0) fprintf(output,"Streamer \n"); else fprintf(output,"Strike   \n");
			fprintf(output,"Primary F0 = %lf   Secondary F0 = %lf\n",1/(2 * pi * sqrt(L1 * C1)), 1/(2 * pi * sqrt(L2 * C2)));
			fprintf(output,"Load Energy Rise Time (uSec) = %lf \n", TEload*1e6);
			fclose(output);
			}

			if (ChartSave == 2)
			{
 			data=fopen(filename4,"a");
			fprintf(data,"%li,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le,%le\n", ModelNumber,C1,R1,L1,L2,K12,R2,C2,C3,
			R3,BPS,DwellTime,fabs(ILpri_max),Cpri_RMSi,fabs(VCpri_max),Isec_RMSi,fabs(VCsec_max),CoilPower,Eload*BPS,1/(2 * pi * sqrt(L1 * C1)),1/(2 * pi * sqrt(L2 * C2)),TEload,LeaderLength);
			fclose(data);
			}

if (ChartSave == 1) goto MainCalc;


}}}}}}}}}} // Returns for C1 through DwellTime loops - No C3 loop now

	printf("\nModels Tested = %ld / %ld \n", ModelNumber, LoopTotal);

	output=fopen(filename1,"a");
	fprintf(output,"\nModels Tested = %ld / %ld \n", ModelNumber, LoopTotal);
	fclose(output);

    return(1);

}  // End of Main

